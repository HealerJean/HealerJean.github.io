package org.study.mq.activeMQ.dt.dao;

import org.springframework.stereotype.Repository;

@Repository
public class UserEventDao extends BaseEventDao{
}
