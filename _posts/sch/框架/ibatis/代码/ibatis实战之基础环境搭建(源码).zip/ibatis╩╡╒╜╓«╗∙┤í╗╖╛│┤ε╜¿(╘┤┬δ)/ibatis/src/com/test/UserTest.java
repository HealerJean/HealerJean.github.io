package com.test;

import java.sql.SQLException;

import com.ibatis.sqlmap.client.SqlMapClient;
import com.itmyhome.User;


public class UserTest {

	public static void main(String[] args) {
		SqlMapClient sqlMap = MyAppSqlConfig.getSqlMapInstance(); 
		try {
			//查询
			User user = (User)sqlMap.queryForObject ("getUser", 2);
			System.out.println(user.getName());
			
			//插入
			/*User u = new User();
			u.setId(3);
			u.setName("wangwu");
			u.setAge(23);
			sqlMap.insert("insertUser",u);*/
			
			//更新
			/*User u2 = new User();
			u2.setId(3);
			u2.setName("itmyhome2");
			u2.setAge(25);
			sqlMap.update("updateUser",u2);*/
			
			//删除
			/*sqlMap.delete("deleteUser", 1);*/
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}
