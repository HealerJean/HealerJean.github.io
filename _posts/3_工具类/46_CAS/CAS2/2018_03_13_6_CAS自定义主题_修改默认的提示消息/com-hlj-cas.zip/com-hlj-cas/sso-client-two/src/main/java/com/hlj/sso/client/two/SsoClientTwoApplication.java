package com.hlj.sso.client.two;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SsoClientTwoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SsoClientTwoApplication.class, args);
	}
}
