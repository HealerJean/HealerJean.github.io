package com.hlj.sso.client.pac4j;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SsoClientPac4jApplication {

	public static void main(String[] args) {
		SpringApplication.run(SsoClientPac4jApplication.class, args);
	}
}
