package com.hlj.sso.client.one;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SsoClientOneApplication {

	public static void main(String[] args) {
		SpringApplication.run(SsoClientOneApplication.class, args);
	}
}