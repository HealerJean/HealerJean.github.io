package com.hlj.quartz.ddkj.monitor;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ComHljQuartzDdkjMonitorApplication {

	public static void main(String[] args) {
		SpringApplication.run(ComHljQuartzDdkjMonitorApplication.class, args);
	}
}
