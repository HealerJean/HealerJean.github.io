package com.hlj.github.maven.repo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ComHljGithubMavenRepoApplication {

	public static void main(String[] args) {


		SpringApplication.run(ComHljGithubMavenRepoApplication.class, args);
	}
}
