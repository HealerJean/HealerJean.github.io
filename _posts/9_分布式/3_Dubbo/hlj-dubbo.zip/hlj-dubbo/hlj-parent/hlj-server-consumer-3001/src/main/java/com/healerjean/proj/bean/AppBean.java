package com.healerjean.proj.bean;

/**
 * @author HealerJean
 * @ClassName AppBean
 * @date 2020/6/24  18:50.
 * @Description
 */
public class AppBean {
}
