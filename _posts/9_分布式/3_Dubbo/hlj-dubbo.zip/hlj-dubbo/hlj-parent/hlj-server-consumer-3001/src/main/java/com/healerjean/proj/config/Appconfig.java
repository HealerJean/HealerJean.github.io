package com.healerjean.proj.config;

import org.springframework.context.annotation.Configuration;

/**
 * @author HealerJean
 * @ClassName Appconfig
 * @date 2020/6/24  18:48.
 * @Description
 */
@Configuration
public class Appconfig {

}
