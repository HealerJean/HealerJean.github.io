package com.healerjean.proj.service;

import com.alibaba.dubbo.common.extension.SPI;

/**
 * @author HealerJean
 * @ClassName Fruits
 * @date 2020-06-27  17:30.
 * @Description
 */
@SPI
public interface Fruits {

    void name();

}
