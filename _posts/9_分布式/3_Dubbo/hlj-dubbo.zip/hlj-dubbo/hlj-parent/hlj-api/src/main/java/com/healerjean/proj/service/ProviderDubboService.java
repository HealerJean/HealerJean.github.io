package com.healerjean.proj.service;

/**
 * @author HealerJean
 * @ClassName FeIgnProviderService
 * @date 2020/4/9  12:40.
 * @Description
 */
public interface ProviderDubboService {

    String connect(String name);

}
