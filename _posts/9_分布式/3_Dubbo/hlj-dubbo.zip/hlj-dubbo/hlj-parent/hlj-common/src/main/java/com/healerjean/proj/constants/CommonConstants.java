package com.healerjean.proj.constants;

/**
 * @author HealerJean
 * @ClassName CommonConstants
 * @date 2020/6/24  16:07.
 * @Description
 */
public class CommonConstants {

    public static final String LOG_REQ_UID = "REQ_UID";

}
