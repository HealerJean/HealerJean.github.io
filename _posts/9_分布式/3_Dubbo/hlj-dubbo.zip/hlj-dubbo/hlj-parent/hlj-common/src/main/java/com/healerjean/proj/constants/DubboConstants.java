package com.healerjean.proj.constants;

/**
 * @author HealerJean
 * @ClassName DubboConstants
 * @date 2020/6/24  16:15.
 * @Description
 */
public class DubboConstants {

    public static final String DUBBO_DEFAULT_GROUP = "hlj_group" ;

}
