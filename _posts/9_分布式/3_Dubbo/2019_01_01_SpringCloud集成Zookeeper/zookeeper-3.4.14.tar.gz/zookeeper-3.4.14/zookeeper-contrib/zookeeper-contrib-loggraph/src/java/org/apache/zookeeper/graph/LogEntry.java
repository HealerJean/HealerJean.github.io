/**
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.zookeeper.graph;

import java.io.Serializable;
import java.util.HashMap;

public abstract class LogEntry implements Serializable {
    private HashMap attributes;

    public enum Type { UNKNOWN, LOG4J, TXN };
        
    public LogEntry(long timestamp) {
	attributes = new HashMap();
	setAttribute("timestamp", new Long(timestamp));
    }
    
    public long getTimestamp() {
	return (Long)getAttribute("timestamp");
    }    
    
    public abstract Type getType();
    
    public void setAttribute(String key, Object v) {
	attributes.put(key, v);
    }

    public Object getAttribute(String key) {
	return attributes.get(key);
    }
}
